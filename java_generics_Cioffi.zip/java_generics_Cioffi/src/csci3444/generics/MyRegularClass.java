package csci3444.generics;

public class MyRegularClass {
	
	public static void main(String[] args) {
		MyGenInterface<Integer, String> mgi1;
		MyGenInterface<Integer, Integer> mgi2;
		
		mgi1 = new MyGenClass<>(1, "Chris Cioffi");
		mgi2 = new MyGenClass<>(1, 2017);
		
		int i1 = MyRegularClass.getSum(10, 20);
		Float f1 = MyRegularClass.getSum(100f, 200f);
		
		System.out.println("Key: " + mgi1.getKey() + " Value: " + mgi2.getValue());
		System.out.println("i1: " + i1 + " f1: " + f1);
	}

	private static int getSum(int i, int j) {
		// TODO Auto-generated method stub
	 int sum = i+j;
	 return sum;
	}
	public static float getSum (float i , float j) {
		float sum = i + j;
		return sum;
	}

}
