package csci3444.generics;

public interface MyGenInterface<K,V> {
	public K getKey();
	public V getValue();
	
}
