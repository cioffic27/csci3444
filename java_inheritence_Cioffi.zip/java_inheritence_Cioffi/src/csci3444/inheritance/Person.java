package csci3444.inheritance;

public interface Person {
	public String  getName();
	public String getDetails();
}
