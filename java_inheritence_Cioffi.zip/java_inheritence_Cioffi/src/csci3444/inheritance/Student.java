package csci3444.inheritance;

public interface Student extends Person  {
	public String studiesFor();
}
