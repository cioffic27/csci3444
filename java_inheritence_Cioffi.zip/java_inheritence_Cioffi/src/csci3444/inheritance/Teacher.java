package csci3444.inheritance;

public interface Teacher extends Person{
	public String teachsfor();
}